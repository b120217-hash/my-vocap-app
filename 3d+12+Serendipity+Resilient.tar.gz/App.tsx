import React, { useEffect, useMemo, useRef, useState } from "react";
import { BookOpen, Brain, Check, ChevronRight, Flame, GraduationCap, Heart, Pencil, Plus, RotateCcw, Search, Sparkles, Star, Trash2, Trophy, Volume2, X } from "lucide-react";

type Status = "new" | "still" | "familiar" | "known";
type Word = { word:string; pos:string; meaning:string; example:string; pronunciation:string; status:Status; attempts:number; correct:number };
type Rec = { id:string; value:any; created_at?:string; updated_at?:string };
type Meta = { streak:number; lastStudyDate:string; todayDate:string; todayCount:number; totalCorrect:number; totalAttempts:number };

const SEED: Word[] = [
  {word:"serendipity",pos:"名詞",meaning:"意外發現美好事物的驚喜",example:"We met by pure serendipity at the little bookshop.",pronunciation:"塞倫迪皮提",status:"new",attempts:0,correct:0},
  {word:"resilient",pos:"形容詞",meaning:"有韌性的；能快速恢復的",example:"She is resilient and never gives up easily.",pronunciation:"瑞西里恩特",status:"new",attempts:0,correct:0},
  {word:"wanderlust",pos:"名詞",meaning:"強烈的旅行渴望",example:"His wanderlust makes him plan a trip every season.",pronunciation:"汪德拉斯特",status:"new",attempts:0,correct:0},
  {word:"cozy",pos:"形容詞",meaning:"舒適溫暖的",example:"I love reading in a cozy corner with hot cocoa.",pronunciation:"摳西",status:"new",attempts:0,correct:0},
  {word:"gratitude",pos:"名詞",meaning:"感恩、感謝之情",example:"She wrote a letter full of gratitude to her teacher.",pronunciation:"格拉提度",status:"new",attempts:0,correct:0},
  {word:"adventure",pos:"名詞",meaning:"冒險；奇遇",example:"Every walk in the forest feels like a new adventure.",pronunciation:"艾德文雀",status:"new",attempts:0,correct:0},
  {word:"embrace",pos:"動詞",meaning:"擁抱；欣然接受",example:"Let’s embrace this challenge with a smile.",pronunciation:"恩布瑞斯",status:"new",attempts:0,correct:0},
  {word:"sparkle",pos:"動詞",meaning:"閃爍；閃耀",example:"Her eyes sparkle when she talks about her dream.",pronunciation:"斯帕克爾",status:"new",attempts:0,correct:0},
  {word:"gentle",pos:"形容詞",meaning:"溫柔的；輕柔的",example:"Please speak in a gentle voice to the baby cat.",pronunciation:"詹特爾",status:"new",attempts:0,correct:0},
  {word:"curious",pos:"形容詞",meaning:"好奇的",example:"Curious kids love to ask why all day long.",pronunciation:"キュリアス / 可利爾斯",status:"new",attempts:0,correct:0},
  {word:"bloom",pos:"動詞",meaning:"開花；蓬勃發展",example:"Flowers bloom again when spring comes back.",pronunciation:"布魯姆",status:"new",attempts:0,correct:0},
  {word:"journey",pos:"名詞",meaning:"旅程；歷程",example:"Learning is a long and beautiful journey.",pronunciation:"傑尼",status:"new",attempts:0,correct:0},
];
const todayStr = () => new Date().toISOString().slice(0,10);
const yesterdayStr = () => { const d=new Date(); d.setDate(d.getDate()-1); return d.toISOString().slice(0,10); };

async function api(action:string, args:any){
  const res = await fetch("actions", {method:"POST", headers:{"content-type":"application/json"}, body: JSON.stringify({action, args})});
  const json = await res.json().catch(()=>({}));
  if(!res.ok || json.error) throw new Error(json.error || `儲存服務回應 ${res.status}`);
  return json.data;
}

export default function App(){
  const [tab,setTab]=useState<"study"|"quiz"|"library">("study");
  const [records,setRecords]=useState<Rec[]>([]);
  const [metaRec,setMetaRec]=useState<Rec|null>(null);
  const [loading,setLoading]=useState(true);
  const [offline,setOffline]=useState(false);
  const [message,setMessage]=useState("");
  const [busy,setBusy]=useState(false);
  const [flipped,setFlipped]=useState(false);
  const [studyFilter,setStudyFilter]=useState<"all"|"still"|"known">("all");
  const [reviewOnly,setReviewOnly]=useState(false);
  const [index,setIndex]=useState(0);
  const [celebrate,setCelebrate]=useState(false);
  const [libraryFilter,setLibraryFilter]=useState<"all"|"still"|"known">("all");
  const [query,setQuery]=useState("");
  const [showForm,setShowForm]=useState(false);
  const [editingId,setEditingId]=useState<string|null>(null);
  const [form,setForm]=useState<Word>({word:"",pos:"名詞",meaning:"",example:"",pronunciation:"",status:"new",attempts:0,correct:0});
  const [deleteId,setDeleteId]=useState<string|null>(null);
  const [showBackup,setShowBackup]=useState(false);
  const [backupText,setBackupText]=useState("");
  const [seedResult,setSeedResult]=useState<string>("");
  const backupRef=useRef<HTMLTextAreaElement>(null);

  // Quiz
  const [quiz,setQuiz]=useState<{q:Word; options:string[]; picked:string|null; correct:boolean|null}[]>([]);
  const [quizIdx,setQuizIdx]=useState(0);
  const [quizDone,setQuizDone]=useState(false);

  const words = useMemo(()=> records.map(r=>({id:r.id, ...(r.value as Word)})), [records]);
  const meta:Meta = (metaRec?.value as Meta) || {streak:0,lastStudyDate:"",todayDate:todayStr(),todayCount:0,totalCorrect:0,totalAttempts:0};

  async function reloadRecords(){
    const [w,m]=await Promise.all([api("records.list",{collection:"words"}), api("records.list",{collection:"progress"})]);
    setRecords(w.records||[]); setMetaRec((m.records||[])[0]||null);
  }
  async function createRow(row:any, collection:string, key:string){
    return api("records.create",{collection,value:row,idempotency_key:key});
  }

  useEffect(()=>{ (async()=>{
    try{
      await reloadRecords();
      const listed = await api("records.list",{collection:"words"});
      if((listed.records||[]).length===0){
        await seedExamples(true);
      }
    }catch(e){ setOffline(true); setRecords(SEED.map((v,i)=>({id:`seed-${i}`,value:v}))); }
    finally{ setLoading(false); }
  })(); },[]);

  async function seedExamples(silent=false){
    setBusy(true); setSeedResult("");
    let saved=0; let error:string|null=null;
    const rows = SEED;
    try{
      for(let i=0;i<rows.length;i++){
        await createRow(rows[i],"words",`seed-${rows[i].word}-${i}`);
        saved+=1;
      }
    }catch(e){ error=e instanceof Error?e.message:String(e); }
    let reloadError:string|null=null;
    try{ await reloadRecords(); }catch(e){ reloadError=e instanceof Error?e.message:String(e); setOffline(true); }
    setSeedResult(error?`已建立 ${saved} 張，尚有 ${rows.length-saved} 張未建立：${error}`:`已建立 ${saved} 張範例卡片！`);
    if(!silent) setMessage(error?`部分範例未完成：${error}`:"✨ 已重置為 12 張範例單字！");
    setBusy(false);
  }

  async function saveMeta(next:Meta){
    if(!metaRec){ try{ const r=await api("records.create",{collection:"progress",value:next,idempotency_key:`progress-${Date.now()}`}); setMetaRec(r);}catch{} }
    else { try{ const r=await api("records.replace",{collection:"progress",id:metaRec.id,value:next}); setMetaRec(r);}catch{} }
  }
  async function recordStudy(outcome:"still"|"familiar"|"known", card:any){
    const today=todayStr();
    let streak=meta.streak; let todayCount=meta.todayCount;
    if(meta.todayDate!==today){ streak = meta.lastStudyDate===yesterdayStr()? meta.streak+1 : (meta.streak>0 && meta.lastStudyDate===today?meta.streak:1); todayCount=0; }
    const isCorrect = outcome==="known" || outcome==="familiar";
    const nextMeta:Meta={streak,lastStudyDate:today,todayDate:today,todayCount:todayCount+1,totalCorrect:meta.totalCorrect+(isCorrect?1:0),totalAttempts:meta.totalAttempts+1};
    saveMeta(nextMeta);
    const nextVal:Word={...card, status:outcome, attempts:(card.attempts||0)+1, correct:(card.correct||0)+(isCorrect?1:0)};
    try{ const r=await api("records.replace",{collection:"words",id:card.id,value:nextVal}); setRecords(p=>p.map(x=>x.id===card.id?r:x)); }
    catch{ setOffline(true); setRecords(p=>p.map(x=>x.id===card.id?{...x,value:nextVal}:x)); }
    if(outcome==="known"){ setCelebrate(true); setTimeout(()=>setCelebrate(false),1300); }
    setMessage(outcome==="known"?"太棒了！這張你會了 🎉":outcome==="familiar"?"有印象了，繼續加油！":"沒關係，多看幾次就會記住囉 💪");
    setFlipped(false); setTimeout(()=>setIndex(i=>Math.min(i+1, Math.max(0, deck.length-1))), 180);
  }

  const deck = useMemo(()=>{
    let list=[...words];
    if(reviewOnly) list=list.filter(w=>w.status==="still");
    else if(studyFilter==="still") list=list.filter(w=>w.status==="still"||w.status==="new");
    else if(studyFilter==="known") list=list.filter(w=>w.status==="known");
    return list;
  },[words,studyFilter,reviewOnly]);
  const current = deck[Math.min(index, Math.max(0, deck.length-1))];
  const reviewed = words.filter(w=>w.status!=="new").length;
  const accuracy = meta.totalAttempts? Math.round(meta.totalCorrect/meta.totalAttempts*100): (words.reduce((a,w)=>a+w.correct,0) && words.reduce((a,w)=>a+w.attempts,0) ? Math.round(words.reduce((a,w)=>a+w.correct,0)/words.reduce((a,w)=>a+w.attempts,0)*100):0);
  const progressPct = words.length? Math.round(reviewed/words.length*100):0;

  function startQuiz(){
    if(words.length<4){ setMessage("單字還不夠 4 張，先去新增一點單字吧！"); return; }
    const shuffled=[...words].sort(()=>Math.random()-0.5).slice(0,Math.min(8,words.length));
    const qs=shuffled.map(q=>{
      const others=[...words].filter(w=>w.word!==q.word).sort(()=>Math.random()-0.5).slice(0,3).map(w=>w.meaning);
      return {q, options:[q.meaning,...others].sort(()=>Math.random()-0.5), picked:null, correct:null};
    });
    setQuiz(qs); setQuizIdx(0); setQuizDone(false); setMessage("測驗開始囉，放輕鬆作答！");
  }
  function answerQuiz(choice:string){
    if(!quiz[quizIdx] || quiz[quizIdx].picked) return;
    const correct = choice===quiz[quizIdx].q.meaning;
    const next=[...quiz]; next[quizIdx]={...next[quizIdx],picked:choice,correct};
    setQuiz(next);
    if(correct){ setCelebrate(true); setTimeout(()=>setCelebrate(false),1100); }
    // record attempt on card
    const card=quiz[quizIdx].q;
    const nextVal:Word={...card, attempts:(card.attempts||0)+1, correct:(card.correct||0)+(correct?1:0), status: correct? card.status : "still"};
    api("records.replace",{collection:"words",id:card.id,value:nextVal}).then(r=>setRecords(p=>p.map(x=>x.id===card.id?r:x))).catch(()=>{});
    const nm:Meta={...meta,totalCorrect:meta.totalCorrect+(correct?1:0),totalAttempts:meta.totalAttempts+1,todayDate:todayStr(),lastStudyDate:todayStr(),todayCount:(meta.todayDate===todayStr()?meta.todayCount+1:1),streak:meta.todayDate===todayStr()?meta.streak:(meta.lastStudyDate===yesterdayStr()?meta.streak+1:1)};
    saveMeta(nm);
  }
  const quizScore = quiz.filter(q=>q.correct).length;

  const filteredLibrary = words.filter(w=>{
    const okFilter = libraryFilter==="all" || (libraryFilter==="still"? (w.status==="still"||w.status==="new") : w.status==="known");
    const q=query.trim().toLowerCase();
    const okQ=!q || w.word.toLowerCase().includes(q) || w.meaning.includes(q) || w.example.toLowerCase().includes(q);
    return okFilter && okQ;
  });

  async function submitWord(){
    if(!form.word.trim()||!form.meaning.trim()){ setMessage("請至少填寫「單字」和「中文意思」喔！"); return; }
    setBusy(true);
    try{
      if(editingId){
        const r=await api("records.replace",{collection:"words",id:editingId,value:{...form,status:form.status,attempts:form.attempts,correct:form.correct}});
        setRecords(p=>p.map(x=>x.id===editingId?r:x)); setMessage(`已更新「${form.word}」！`);
      } else {
        const r=await api("records.create",{collection:"words",value:{...form,status:"new",attempts:0,correct:0},idempotency_key:`word-${Date.now()}-${form.word}`});
        setRecords(p=>[r,...p]); setMessage(`已新增「${form.word}」！`);
      }
      setShowForm(false); setEditingId(null); setForm({word:"",pos:"名詞",meaning:"",example:"",pronunciation:"",status:"new",attempts:0,correct:0});
    }catch(e){ setOffline(true); setMessage("儲存服務暫時無法連線，這張卡片還沒有真正儲存。"); }
    setBusy(false);
  }
  async function deleteWord(id:string){
    try{ await api("records.delete",{collection:"words",id}); setRecords(p=>p.filter(x=>x.id!==id)); setMessage("已刪除這張卡片。"); }
    catch{ setMessage("刪除失敗，請稍後再試。"); }
    setDeleteId(null);
  }
  async function resetAll(){
    if(!confirmReset){ setConfirmReset(true); return; }
    setBusy(true);
    try{
      const listed=await api("records.list",{collection:"words"});
      for(const r of listed.records||[]) await api("records.delete",{collection:"words",id:r.id});
      await reloadRecords(); await seedExamples(true); setMessage("已重置為範例單字！"); setConfirmReset(false); setIndex(0);
    }catch{ setMessage("重置失敗，請檢查連線後再試。"); }
    setBusy(false);
  }
  const [confirmReset,setConfirmReset]=useState(false);
  function openExport(){
    const data={exportedAt:new Date().toISOString(), words: words.map(w=>w), progress: meta};
    setBackupText(JSON.stringify(data,null,2)); setShowBackup(true);
  }
  function selectBackup(){
    backupRef.current?.focus(); backupRef.current?.select();
    try{ document.execCommand("copy"); setMessage("備份文字已選取並嘗試複製，請貼到筆記裡保存。"); }catch{ setMessage("已選取備份文字，請按 Ctrl+C 複製。"); }
  }

  if(loading) return <div style={{boxSizing:"border-box",minHeight:"100vh",background:"var(--bg)",display:"grid",placeItems:"center",padding:20}}><div style={{textAlign:"center"}}><div className="animate-floaty" style={{fontSize:52}}>📚</div><p>小老師正在準備單字卡…</p></div></div>;

  return (
    <div data-safe-area-inset-root style={{boxSizing:"border-box",paddingTop:"var(--safe-area-inset-top)",minHeight:"100vh",background:"var(--bg)",color:"var(--ink)"}} className="overflow-x-clip">
      <div style={{maxWidth:980,margin:"0 auto",padding:"14px 16px 110px"}}>
        {/* Header */}
        <header style={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:12}}>
          <div style={{display:"flex",gap:11,alignItems:"center"}}>
            <div style={{width:52,height:52,borderRadius:18,background:"#FF8A5C",display:"grid",placeItems:"center",fontSize:28,boxShadow:"0 8px 20px rgba(255,138,92,.35)"}}>📖</div>
            <div><div className="font-display" style={{fontSize:22,lineHeight:1,fontWeight:700}}>單字卡片小老師</div><div style={{fontSize:12,color:"var(--muted)",marginTop:4}}>每天一點點，英文慢慢變厲害 ✨</div></div>
          </div>
          <div style={{background:"var(--surface)",border:"1px solid var(--line)",borderRadius:999,padding:"7px 12px",display:"flex",gap:6,alignItems:"center",boxShadow:"var(--shadow)"}}><Flame size={17} color="#FF6B35"/><b>{meta.streak}</b><span style={{fontSize:12}}>天連續</span></div>
        </header>

        {offline && <div style={{marginTop:12,background:"#FFF3CD",border:"1px solid #FFE08A",padding:"10px 12px",borderRadius:14,fontSize:13}}>儲存服務暫時無法連線，目前看到的是範例內容。連線恢復後，你的新增與編輯才會真正儲存。</div>}
        {message && <div className="animate-fadeUp" style={{marginTop:12,background:"var(--surface)",border:"1px solid var(--line)",padding:"10px 12px",borderRadius:14,fontSize:13,display:"flex",justifyContent:"space-between",gap:10}}><span>{message}</span><button onClick={()=>setMessage("")} style={{border:0,background:"transparent",cursor:"pointer"}}><X size={16}/></button></div>}

        {/* Progress */}
        <section style={{marginTop:14,background:"var(--surface)",borderRadius:24,padding:18,boxShadow:"var(--shadow)",border:"1px solid var(--line)"}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}><h2 style={{margin:0,fontSize:16}}>🌱 今日進度</h2><span style={{fontSize:12,background:"#FFF1D6",padding:"5px 10px",borderRadius:999}}>今天已複習 {meta.todayDate===todayStr()?meta.todayCount:0} 張</span></div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10,marginTop:14}}>
            <div style={{background:"var(--surface2)",borderRadius:16,padding:12,textAlign:"center"}}><div style={{fontSize:22,fontWeight:900}}>{reviewed}<span style={{fontSize:13,color:"var(--muted)"}}> / {words.length}</span></div><div style={{fontSize:12,color:"var(--muted)"}}>已複習張數</div></div>
            <div style={{background:"#FFE9F0",borderRadius:16,padding:12,textAlign:"center"}}><div style={{fontSize:22,fontWeight:900}}>{meta.streak} 天</div><div style={{fontSize:12,color:"var(--muted)"}}>連續學習</div></div>
            <div style={{background:"#E8F7EF",borderRadius:16,padding:12,textAlign:"center"}}><div style={{fontSize:22,fontWeight:900}}>{accuracy}%</div><div style={{fontSize:12,color:"var(--muted)"}}>正確率</div></div>
          </div>
          <div style={{display:"flex",justifyContent:"space-between",fontSize:12,marginTop:14,color:"var(--muted)"}}><span>完成度</span><b style={{color:"var(--ink)"}}>{progressPct}%</b></div>
          <div style={{height:14,background:"#F3E6CF",borderRadius:999,overflow:"hidden",marginTop:6}}><div className="progress-fill" style={{height:"100%",width:`${progressPct}%`,background:"linear-gradient(90deg,#FF8A5C,#FFB627)",borderRadius:999,transition:"width .6s"}} /></div>
          <p style={{fontSize:12,color:"var(--muted)",margin:"8px 0 0"}}>小提醒：點卡片可以翻面看中文意思，按下方按鈕記錄你記得怎麼樣。</p>
        </section>

        {tab==="study" && (
          <main className="animate-fadeUp">
            <div style={{display:"flex",gap:8,flexWrap:"wrap",marginTop:16}}>
              {(["all","still","known"] as const).map(f=><button key={f} onClick={()=>{setStudyFilter(f);setReviewOnly(false);setIndex(0);}} style={{border:0,padding:"10px 14px",borderRadius:999,cursor:"pointer",fontWeight:700,background: !reviewOnly && studyFilter===f ? "#3D2C22":"var(--surface)",color: !reviewOnly && studyFilter===f ? "#fff":"var(--ink)",boxShadow:"var(--shadow)"}}>{f==="all"?"全部":f==="still"?"還不會":"已學會"}</button>)}
              <button onClick={()=>{setReviewOnly(!reviewOnly);setIndex(0);}} style={{border: reviewOnly?"2px solid #FF5A5A":"1px solid var(--line)",padding:"9px 14px",borderRadius:999,cursor:"pointer",fontWeight:700,background: reviewOnly?"#FFE8E8":"var(--surface)"}}>💔 複習錯題 {reviewOnly?"（開啟中）":""}</button>
            </div>

            {deck.length===0 ? (
              <div style={{marginTop:16,background:"var(--surface)",borderRadius:24,padding:34,textAlign:"center",boxShadow:"var(--shadow)"}}><div style={{fontSize:52}}>🌸</div><h3>這裡空空的耶！</h3><p style={{color:"var(--muted)"}}>{reviewOnly?"太棒了，目前沒有標記「還不會」的卡片！":"還沒有單字，快去新增第一張卡片吧"}</p><button onClick={()=>setTab("library")} style={{marginTop:8,background:"var(--primary)",color:"#fff",border:0,padding:"12px 20px",borderRadius:999,fontWeight:800,cursor:"pointer"}}>去新增單字 →</button></div>
            ) : (
              <>
                <div style={{textAlign:"center",margin:"14px 0 8px",fontSize:13,color:"var(--muted)"}}>第 {Math.min(index+1,deck.length)} / {deck.length} 張 · {current?.status==="known"?"✅ 已學會":current?.status==="still"?"💔 還不會":current?.status==="familiar"?"🌼 有點印象":"🆕 新單字"}</div>
                <div className="perspective" style={{position:"relative"}}>
                  {celebrate && <div style={{position:"absolute",inset:0,zIndex:5,display:"flex",justifyContent:"center"}}>{["🎉","⭐","🌈","💛","🎊","✨"].map((e,i)=><span key={i} className="confetti" style={{left:`${18+i*13}%`,fontSize:26,animationDelay:`${i*0.08}s`}}>{e}</span>)}</div>}
                  <button onClick={()=>setFlipped(v=>!v)} aria-label="翻面看中文意思" style={{width:"100%",border:0,background:"transparent",cursor:"pointer",padding:0,textAlign:"left"}}>
                    <div className={`preserve3d ${flipped?"flipped":""}`} style={{position:"relative",minHeight:330}}>
                      {/* Front */}
                      <div className="backface" style={{position:"absolute",inset:0,background:"linear-gradient(145deg,#FF8A5C,#FFB627)",borderRadius:28,padding:26,color:"#fff",boxShadow:"0 20px 40px rgba(255,138,92,.35)",display:"flex",flexDirection:"column",justifyContent:"space-between"}}>
                        <div style={{display:"flex",justifyContent:"space-between"}}><span style={{background:"rgba(255,255,255,.25)",padding:"6px 11px",borderRadius:999,fontSize:12}}>✦ {current?.pos}</span><span style={{fontSize:20}}>☁️</span></div>
                        <div style={{textAlign:"center"}}><div className="font-display" style={{fontSize:"clamp(38px,9vw,64px)",lineHeight:1.05,fontWeight:700,wordBreak:"break-word"}}>{current?.word}</div><div style={{marginTop:14,fontSize:15,opacity:.95}}>🗣️ 發音提示：{current?.pronunciation || "跟著唸唸看"}</div><div style={{marginTop:18,background:"rgba(255,255,255,.22)",borderRadius:16,padding:"12px 14px",fontSize:14,lineHeight:1.6}}>💡 例句提示<br/>{current?.example}</div></div>
                        <div style={{textAlign:"center",fontSize:13,opacity:.9}}>👆 點卡片翻面看中文意思</div>
                      </div>
                      {/* Back */}
                      <div className="backface backface-back" style={{position:"absolute",inset:0,background:"var(--surface)",border:"2px solid #FFD9A8",borderRadius:28,padding:26,boxShadow:"var(--shadow)",display:"flex",flexDirection:"column",justifyContent:"space-between"}}>
                        <div style={{textAlign:"center"}}><div style={{fontSize:13,color:"var(--muted)"}}>{current?.word}</div><div style={{fontSize:"clamp(30px,7vw,42px)",fontWeight:900,marginTop:8,lineHeight:1.2}}>{current?.meaning}</div><div style={{marginTop:18,background:"var(--surface2)",padding:14,borderRadius:16,textAlign:"left",fontSize:14,lineHeight:1.7}}><b>例句</b><br/>{current?.example}<br/><span style={{color:"var(--muted)"}}>🗣️ 發音提示：{current?.pronunciation}</span></div></div>
                        <div style={{textAlign:"center",fontSize:13,color:"var(--muted)"}}>👆 再點一次回到正面</div>
                      </div>
                    </div>
                  </button>
                </div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1.2fr",gap:10,marginTop:14}}>
                  <button onClick={()=>current && recordStudy("still",current)} style={{border:0,background:"#FFE8E8",color:"#B42318",padding:"15px 8px",borderRadius:18,fontWeight:800,cursor:"pointer"}}>😵<br/>還不會<br/><span style={{fontWeight:400,fontSize:11}}>再看一次</span></button>
                  <button onClick={()=>current && recordStudy("familiar",current)} style={{border:0,background:"#FFF1D6",color:"#8A5A00",padding:"15px 8px",borderRadius:18,fontWeight:800,cursor:"pointer"}}>🤔<br/>有點印象</button>
                  <button onClick={()=>current && recordStudy("known",current)} style={{border:0,background:"#2EAF7A",color:"#fff",padding:"15px 8px",borderRadius:18,fontWeight:800,cursor:"pointer",boxShadow:"0 8px 18px rgba(46,175,122,.3)"}}>🎉<br/>我會了！</button>
                </div>
                <div style={{display:"flex",justifyContent:"space-between",marginTop:12}}><button onClick={()=>{setIndex(i=>Math.max(0,i-1));setFlipped(false);}} disabled={index===0} style={{border:"1px solid var(--line)",background:"var(--surface)",padding:"10px 16px",borderRadius:999,cursor:"pointer"}}>← 上一張</button><button onClick={()=>{setIndex(i=>Math.min(deck.length-1,i+1));setFlipped(false);}} style={{border:"1px solid var(--line)",background:"var(--surface)",padding:"10px 16px",borderRadius:999,cursor:"pointer"}}>下一張 →</button></div>
              </>
            )}
            <div style={{marginTop:18,background:"var(--surface)",borderRadius:20,padding:16,border:"1px solid var(--line)"}}><b>💛 新手小提示</b><p style={{fontSize:13,lineHeight:1.7,color:"var(--muted)",margin:"6px 0 0"}}>第一次不用急著全部背完。先翻 5 張，答對就給自己一個大大的讚！標記「還不會」的卡片會出現在「複習錯題」裡，睡前再看一次效果最好。</p></div>
          </main>
        )}

        {tab==="quiz" && (
          <main className="animate-fadeUp">
            <div style={{marginTop:16,background:"linear-gradient(135deg,#8B7CF6,#FF6B9D)",color:"#fff",borderRadius:24,padding:22,boxShadow:"var(--shadow)"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}><div><h2 style={{margin:0,fontSize:22}}>🧩 測驗模式</h2><p style={{opacity:.9,fontSize:13,margin:"6px 0 0"}}>隨機出題 · 4 選 1 · 即時知道對不對</p></div><Trophy size={38}/></div>
              {!quiz.length || quizDone ? <button onClick={startQuiz} style={{marginTop:16,background:"#fff",color:"#5B3FD6",border:0,padding:"13px 20px",borderRadius:999,fontWeight:900,cursor:"pointer",width:"100%"}}>🚀 {quizDone?"再玩一次":"開始測驗"}</button> : <div style={{marginTop:14,fontSize:13}}>第 {quizIdx+1} / {quiz.length} 題 · 目前得分 {quizScore} 分</div>}
            </div>
            {quiz.length===0 && <div style={{marginTop:14,background:"var(--surface)",padding:20,borderRadius:20,textAlign:"center"}}>按「開始測驗」，小老師會隨機幫你出題喔！</div>}
            {!quizDone && quiz[quizIdx] && (
              <div style={{marginTop:14,background:"var(--surface)",borderRadius:24,padding:20,boxShadow:"var(--shadow)"}}>
                <div style={{fontSize:12,color:"var(--muted)"}}>請選出正確的中文意思</div>
                <div className="font-display" style={{fontSize:"clamp(32px,8vw,48px)",fontWeight:700,margin:"10px 0"}}>{quiz[quizIdx].q.word}</div>
                <div style={{fontSize:13,color:"var(--muted)",marginBottom:14}}>例句：{quiz[quizIdx].q.example}</div>
                <div style={{display:"grid",gap:10}}>
                  {quiz[quizIdx].options.map((opt,i)=>{
                    const picked=quiz[quizIdx].picked; const isRight=opt===quiz[quizIdx].q.meaning;
                    let bg="var(--surface2)", border="1px solid var(--line)";
                    if(picked){ if(isRight){bg="#DFF7EB";border="2px solid #2EAF7A";} else if(picked===opt){bg="#FFE8E8";border="2px solid #FF5A5A";} }
                    return <button key={i} onClick={()=>answerQuiz(opt)} disabled={!!picked} style={{textAlign:"left",background:bg,border,padding:"15px 16px",borderRadius:16,cursor:picked?"default":"pointer",fontWeight:600}}><span style={{marginRight:8}}>{["A","B","C","D"][i]}</span> {opt} {picked && isRight?" ✅":""}{picked===opt && !isRight?" ❌":""}</button>;
                  })}
                </div>
                {quiz[quizIdx].picked && <div style={{marginTop:14,padding:12,borderRadius:14,background: quiz[quizIdx].correct?"#E8F7EF":"#FFF1D6",fontWeight:700}}>{quiz[quizIdx].correct?"🎉 答對了！你超棒！":"💪 答錯也沒關係，正確答案是「"+quiz[quizIdx].q.meaning+"」，這張已幫你加入複習！"}</div>}
                {quiz[quizIdx].picked && <button onClick={()=> quizIdx+1>=quiz.length? setQuizDone(true): setQuizIdx(quizIdx+1)} style={{marginTop:12,width:"100%",background:"#3D2C22",color:"#fff",border:0,padding:"14px",borderRadius:999,fontWeight:800,cursor:"pointer"}}>{quizIdx+1>=quiz.length?"看成績單 →":"下一題 →"}</button>}
              </div>
            )}
            {quizDone && (
              <div style={{marginTop:14,background:"var(--surface)",borderRadius:24,padding:22,boxShadow:"var(--shadow)",textAlign:"center"}}>
                <div style={{fontSize:48}}>🏆</div><h2>測驗完成！</h2><div style={{fontSize:44,fontWeight:900}}>{quizScore} <span style={{fontSize:16,color:"var(--muted)"}}> / {quiz.length} 分</span></div><p>{quizScore===quiz.length?"滿分！你是單字小達人！":quizScore>=quiz.length/2?"很棒，繼續保持！":"沒關係，錯題就是進步的起點。"}</p>
                <div style={{textAlign:"left",marginTop:14}}><b>錯題回顧</b>{quiz.filter(q=>!q.correct).length===0?<p style={{color:"var(--muted)"}}>沒有錯題，太厲害了！</p>:quiz.filter(q=>!q.correct).map((q,i)=><div key={i} style={{background:"#FFF1D6",padding:12,borderRadius:14,marginTop:8}}><b>{q.q.word}</b> — {q.q.meaning}<br/><span style={{fontSize:12,color:"var(--muted)"}}>你選了：{q.picked}</span></div>)}</div>
                <button onClick={()=>setTab("study")} style={{marginTop:16,background:"var(--primary)",color:"#fff",border:0,padding:"12px 20px",borderRadius:999,fontWeight:800,cursor:"pointer"}}>回去複習錯題 💔</button>
              </div>
            )}
          </main>
        )}

        {tab==="library" && (
          <main className="animate-fadeUp">
            <div style={{display:"flex",gap:8,marginTop:16,flexWrap:"wrap"}}>
              <div style={{flex:1,minWidth:180,background:"var(--surface)",borderRadius:999,display:"flex",alignItems:"center",gap:8,padding:"0 14px",border:"1px solid var(--line)"}}><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="搜尋單字 / 中文 / 例句…" style={{border:0,background:"transparent",padding:"12px 0",width:"100%",fontSize:14}} /></div>
              <button onClick={()=>{setShowForm(!showForm);setEditingId(null);setForm({word:"",pos:"名詞",meaning:"",example:"",pronunciation:"",status:"new",attempts:0,correct:0});}} style={{background:"#3D2C22",color:"#fff",border:0,padding:"12px 18px",borderRadius:999,fontWeight:800,cursor:"pointer",display:"flex",gap:6,alignItems:"center"}}><Plus size={18}/> 新增單字</button>
            </div>
            <div style={{display:"flex",gap:8,marginTop:12,flexWrap:"wrap"}}>
              {(["all","still","known"] as const).map(f=><button key={f} onClick={()=>setLibraryFilter(f)} style={{border:0,padding:"9px 14px",borderRadius:999,cursor:"pointer",fontWeight:700,background:libraryFilter===f?"#FF8A5C":"var(--surface)",color:libraryFilter===f?"#fff":"var(--ink)"}}>{f==="all"?`全部（${words.length}）`:f==="still"?"還不會":"已學會"}</button>)}
              <button onClick={openExport} style={{border:"1px solid var(--line)",background:"var(--surface)",padding:"9px 14px",borderRadius:999,cursor:"pointer"}}>📤 匯出備份</button>
              <button onClick={resetAll} disabled={busy} style={{border:"1px solid var(--line)",background:"var(--surface)",padding:"9px 14px",borderRadius:999,cursor:"pointer"}}>{confirmReset?"⚠️ 再按一次確認重置":"↺ 重置範例"}</button>
            </div>
            {seedResult && <p style={{fontSize:12,color:"var(--muted)"}}>{seedResult}</p>}

            {showForm && (
              <div style={{marginTop:14,background:"var(--surface)",borderRadius:22,padding:18,boxShadow:"var(--shadow)",border:"2px solid #FFD9A8"}}>
                <h3 style={{margin:"0 0 12px"}}>{editingId?"✏️ 編輯單字":"➕ 新增一張卡片"}</h3>
                <div style={{display:"grid",gap:10}}>
                  <label style={{fontSize:13}}>單字 *<input value={form.word} onChange={e=>setForm({...form,word:e.target.value})} placeholder="例如：sunshine" style={{display:"block",width:"100%",marginTop:5,padding:12,borderRadius:12,border:"1px solid var(--line)",background:"var(--bg)"}} /></label>
                  <label style={{fontSize:13}}>詞性<select value={form.pos} onChange={e=>setForm({...form,pos:e.target.value})} style={{display:"block",width:"100%",marginTop:5,padding:12,borderRadius:12,border:"1px solid var(--line)",background:"var(--bg)"}}><option>名詞</option><option>動詞</option><option>形容詞</option><option>副詞</option><option>片語</option><option>其他</option></select></label>
                  <label style={{fontSize:13}}>中文意思 *<input value={form.meaning} onChange={e=>setForm({...form,meaning:e.target.value})} placeholder="例如：陽光" style={{display:"block",width:"100%",marginTop:5,padding:12,borderRadius:12,border:"1px solid var(--line)",background:"var(--bg)"}} /></label>
                  <label style={{fontSize:13}}>例句<input value={form.example} onChange={e=>setForm({...form,example:e.target.value})} placeholder="例如：I love the warm sunshine." style={{display:"block",width:"100%",marginTop:5,padding:12,borderRadius:12,border:"1px solid var(--line)",background:"var(--bg)"}} /></label>
                  <label style={{fontSize:13}}>發音提示（用文字）<input value={form.pronunciation} onChange={e=>setForm({...form,pronunciation:e.target.value})} placeholder="例如：桑夏恩" style={{display:"block",width:"100%",marginTop:5,padding:12,borderRadius:12,border:"1px solid var(--line)",background:"var(--bg)"}} /></label>
                </div>
                <div style={{display:"flex",gap:8,marginTop:14}}><button onClick={submitWord} disabled={busy} style={{flex:1,background:"#2EAF7A",color:"#fff",border:0,padding:"13px",borderRadius:999,fontWeight:800,cursor:"pointer"}}>{busy?"儲存中…":"💾 儲存這張卡片"}</button><button onClick={()=>{setShowForm(false);setEditingId(null);}} style={{padding:"13px 18px",borderRadius:999,border:"1px solid var(--line)",background:"var(--surface)",cursor:"pointer"}}>取消</button></div>
              </div>
            )}

            {showBackup && <div style={{marginTop:14,background:"var(--surface)",borderRadius:18,padding:16,border:"1px solid var(--line)"}}><b>📤 備份內容（JSON）</b><p style={{fontSize:12,color:"var(--muted)"}}>點選取後複製，貼到你的筆記或記事本保存。</p><textarea ref={backupRef} readOnly value={backupText} style={{width:"100%",height:140,padding:12,borderRadius:12,border:"1px solid var(--line)",background:"var(--bg)",fontSize:11}} /><div style={{display:"flex",gap:8,marginTop:8}}><button onClick={selectBackup} style={{background:"#3D2C22",color:"#fff",border:0,padding:"10px 16px",borderRadius:999,cursor:"pointer",fontWeight:700}}>選取備份文字</button><button onClick={()=>setShowBackup(false)} style={{border:"1px solid var(--line)",background:"var(--surface)",padding:"10px 16px",borderRadius:999,cursor:"pointer"}}>關閉</button></div></div>}

            <div style={{marginTop:14,display:"grid",gap:10}}>
              {filteredLibrary.length===0 && <div style={{background:"var(--surface)",borderRadius:20,padding:28,textAlign:"center"}}><div style={{fontSize:44}}>🌸</div><p><b>還沒有單字喔</b><br/><span style={{color:"var(--muted)",fontSize:13}}>快去新增第一張卡片吧，你的第一步最重要！</span></p></div>}
              {filteredLibrary.map(w=>(
                <div key={w.id} style={{background:"var(--surface)",borderRadius:20,padding:16,boxShadow:"var(--shadow)",border:"1px solid var(--line)",display:"flex",justifyContent:"space-between",gap:12}}>
                  <div style={{minWidth:0}}><div style={{display:"flex",gap:8,alignItems:"center",flexWrap:"wrap"}}><b style={{fontSize:19}}>{w.word}</b><span style={{fontSize:11,background:"var(--surface2)",padding:"4px 8px",borderRadius:999}}>{w.pos}</span><span style={{fontSize:11}}>{w.status==="known"?"✅ 已學會":w.status==="still"?"💔 還不會":w.status==="familiar"?"🌼 有點印象":"🆕 新單字"}</span></div><div style={{marginTop:5,fontWeight:700}}>{w.meaning}</div><div style={{fontSize:13,color:"var(--muted)",lineHeight:1.6,wordBreak:"break-word"}}>{w.example}<br/>🗣️ {w.pronunciation}</div></div>
                  <div style={{display:"flex",flexDirection:"column",gap:6,flexShrink:0}}>
                    {deleteId===w.id ? <><button onClick={()=>deleteWord(w.id)} style={{background:"#FF5A5A",color:"#fff",border:0,padding:"9px 12px",borderRadius:12,cursor:"pointer",fontSize:12,fontWeight:800}}>確認刪除</button><button onClick={()=>setDeleteId(null)} style={{border:"1px solid var(--line)",background:"var(--surface)",padding:"9px 12px",borderRadius:12,cursor:"pointer",fontSize:12}}>取消</button></> : <><button onClick={()=>{setForm({...w});setEditingId(w.id);setShowForm(true);window.scrollTo({top:0,behavior:"smooth"});}} style={{background:"#FFF1D6",border:0,padding:"9px 12px",borderRadius:12,cursor:"pointer",display:"flex",gap:5,alignItems:"center",fontSize:12,fontWeight:700}}><Pencil size={14}/> 編輯</button><button onClick={()=>setDeleteId(w.id)} style={{background:"#FFE8E8",border:0,padding:"9px 12px",borderRadius:12,cursor:"pointer",display:"flex",gap:5,alignItems:"center",fontSize:12,fontWeight:700}}><Trash2 size={14}/> 刪除</button></>}
                  </div>
                </div>
              ))}
            </div>
            <p style={{fontSize:12,color:"var(--muted)",textAlign:"center",marginTop:14}}>資料會透過安全的儲存服務保存，重新整理也不會消失。儲存空間上限為 1,000 筆記錄。</p>
          </main>
        )}
      </div>

      {/* Bottom nav */}
      <div style={{position:"fixed",left:0,right:0,bottom:0,top:"auto",background:"var(--surface)",borderTop:"1px solid var(--line)",boxShadow:"0 -8px 24px rgba(0,0,0,.06)",zIndex:20}}>
        <div style={{maxWidth:680,margin:"0 auto",display:"grid",gridTemplateColumns:"repeat(3,1fr)",padding:"8px 10px calc(8px + env(safe-area-inset-bottom))"}}>
          {([{k:"study",label:"學習",icon:<BookOpen size={22}/>},{k:"quiz",label:"測驗",icon:<Brain size={22}/>},{k:"library",label:"單字庫",icon:<GraduationCap size={22}/>} ] as const).map(t=>(
            <button key={t.k} onClick={()=>setTab(t.k)} style={{border:0,background: tab===t.k?"#FFF1D6":"transparent",color: tab===t.k?"#E86A2A":"var(--muted)",padding:"8px 4px",borderRadius:16,cursor:"pointer",fontWeight:800,display:"flex",flexDirection:"column",alignItems:"center",gap:2,fontSize:12}}>{t.icon}{t.label}{tab===t.k && <span style={{width:22,height:4,background:"#FF8A5C",borderRadius:999}}/>}</button>
          ))}
        </div>
      </div>
    </div>
  );
}
